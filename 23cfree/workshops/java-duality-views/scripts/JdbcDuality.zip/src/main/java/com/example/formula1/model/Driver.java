package com.example.formula1.model;

public record Driver(int driverId, String name, int points) {

}
