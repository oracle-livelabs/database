prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(16816827077600525)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(16581865756600357)
,p_default_dialog_template=>wwv_flow_imp.id(16576701597600355)
,p_error_template=>wwv_flow_imp.id(16566679715600350)
,p_printer_friendly_template=>wwv_flow_imp.id(16581865756600357)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(16566679715600350)
,p_default_button_template=>wwv_flow_imp.id(16731741709600443)
,p_default_region_template=>wwv_flow_imp.id(16658618210600400)
,p_default_chart_template=>wwv_flow_imp.id(16658618210600400)
,p_default_form_template=>wwv_flow_imp.id(16658618210600400)
,p_default_reportr_template=>wwv_flow_imp.id(16658618210600400)
,p_default_tabform_template=>wwv_flow_imp.id(16658618210600400)
,p_default_wizard_template=>wwv_flow_imp.id(16658618210600400)
,p_default_menur_template=>wwv_flow_imp.id(16670965546600409)
,p_default_listr_template=>wwv_flow_imp.id(16658618210600400)
,p_default_irr_template=>wwv_flow_imp.id(16630898054600388)
,p_default_report_template=>wwv_flow_imp.id(16696743215600421)
,p_default_label_template=>wwv_flow_imp.id(16729275947600439)
,p_default_menu_template=>wwv_flow_imp.id(16733428132600444)
,p_default_calendar_template=>wwv_flow_imp.id(16733499389600444)
,p_default_list_template=>wwv_flow_imp.id(16713204315600430)
,p_default_nav_list_template=>wwv_flow_imp.id(16724939972600436)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(16724939972600436)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(16719601019600434)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(16622165091600384)
,p_default_dialogr_template=>wwv_flow_imp.id(16592005032600366)
,p_default_option_label=>wwv_flow_imp.id(16729275947600439)
,p_default_required_label=>wwv_flow_imp.id(16730556124600440)
,p_default_navbar_list_template=>wwv_flow_imp.id(16719200503600433)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/23.1/')
,p_files_version=>66
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
