prompt --application/shared_components/navigation/lists/loginusers
begin
--   Manifest
--     LIST: LoginUsers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(22508088061577315)
,p_name=>'LoginUsers'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(16842516441600558)
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(22509991963637279)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'LOGIN ADMIN'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:1:::'
,p_list_item_icon=>'fa-user-lock'
,p_list_text_01=>'Login To Your User Account'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(22509466454633898)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'LOGIN USER'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:1:::'
,p_list_item_icon=>'fa-user-play'
,p_list_text_01=>'Login To Your User Account'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
