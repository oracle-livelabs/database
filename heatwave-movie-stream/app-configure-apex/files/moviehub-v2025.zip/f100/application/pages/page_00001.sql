prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7266698827421149
,p_default_application_id=>100
,p_default_id_offset=>8541228906651295
,p_default_owner=>'WKSP_HEATWAVE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'MovieHub - Powered by MySQL HeatWave'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'U'
,p_page_component_map=>'13'
,p_last_updated_by=>'HEATWAVE'
,p_last_upd_yyyymmddhh24miss=>'20231020091738'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16853049886600589)
,p_plug_name=>'MovieHub - Powered by MySQL HeatWave'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16642785814600393)
,p_plug_display_sequence=>10
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22515156873730498)
,p_plug_name=>'LOGIN USER'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16617006640600382)
,p_plug_display_sequence=>30
,p_region_image=>'#APP_FILES#icons/user_play.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22515528601730501)
,p_plug_name=>'LOGIN ADMIN'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16617006640600382)
,p_plug_display_sequence=>40
,p_region_image=>'#APP_FILES#icons/user_admin.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22515584095730502)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(22515528601730501)
,p_button_name=>'AdminPage'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--warning:t-Button--iconLeft:t-Button--hoverIconSpin:t-Button--pill:t-Button--stretch:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(16731846543600443)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Go To Admin Login Page  >>'
,p_button_redirect_url=>'f?p=&APP_ID.:10005:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21900273338633839)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(22515156873730498)
,p_button_name=>'UserPage'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--warning:t-Button--iconLeft:t-Button--hoverIconSpin:t-Button--pill:t-Button--stretch:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(16731846543600443)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Go To User Login Page   >>'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp.component_end;
end;
/
