import pandas as pd
import csv

#Replace the path value with the directory of your files
path = "/home/opc/ml-100k/"


############################################# Modifying ITEM FILE ##########################################



items = pd.read_csv(path+"u.item", sep ="|", encoding="latin", index_col= False, header=None, engine='python', skipinitialspace = True)
items.columns =  columns = ['item_id','title','release_date','release_year','URL','genre_unkown','genre_action','genre_adventure', 'genre_animation', 'genre_children', 'genre_comedy', 'genre_crime', 'genre_documentary', 'genre_drama', 'genre_fantasy', 'genre_filmnoir', 'item.genre_horror', 'genre_musical', 'genre_mystery', 'genre_romance', 'genre_scifi', 'genre_thriller', 'genre_war', 'genre_western']

items['release_year']= items['title'].str.split().str[-1]
items['release_year']= items['release_year'].str.replace(r'\(|\)', '', regex=True)
items['title'] = items['title'].str.replace(r'\s+\S+$', '', regex=True)

# Replace NaN (empty) values in 'release_date' and 'URL' with 0
items['release_date'].fillna(0, inplace=True)
items['URL'].fillna(0, inplace=True)

# Update the 'title' & 'release_year' for 'mov_id' = 1412
items.loc[items['item_id'] == 1412, 'release_year'] = '1995'
items.loc[items['item_id'] == 1412, 'title'] = 'Land Before Time III: The Time of the Great Giving'

items=items.reindex(columns=['item_id','title','release_year','release_date','URL','genre_unkown','genre_action','genre_adventure', 'genre_animation', 'genre_children', 'genre_comedy', 'genre_crime', 'genre_documentary', 'genre_drama', 'genre_fantasy', 'genre_filmnoir', 'item.genre_horror', 'genre_musical', 'genre_mystery', 'genre_romance', 'genre_scifi', 'genre_thriller', 'genre_war', 'genre_western'])
print(items.iloc[[11]])


items.to_csv(path+"item.csv", index=False, sep=',', encoding='cp1252')
print(f"CSV file generated  to item.csv")

############################################# Modifying USER FILE ##########################################


items = pd.read_csv(path+"u.user", sep ="|", encoding="latin", index_col= False, header=None, engine='python', skipinitialspace = True)
items.columns =  columns = ['user_id','user_age','user_gender','user_occupation','user_zipcode']
print(items.iloc[[11]])

items.to_csv(path+"user.csv", index=False, sep=',', encoding='cp1252')
print(f"CSV file generated  to user.csv")

############################################# Modifying DATA FILE ##########################################


items = pd.read_csv(path+"u.data", sep ="\t", encoding="latin", index_col= False, header=None, engine='python', skipinitialspace = True)
items.columns =  columns = ['user_id','item_id','rating','timestamp']
items = items.drop('timestamp', axis=1)
print(items.iloc[[11]])

items.to_csv(path+"data.csv", index=False, sep=',', encoding='cp1252')
print(f"CSV file generated  to data.csv")
