import csv

#Replace the path value with the directory of your files
path = "/home/opc/ml-100k/"


############################################# Modifying ITEM FILE ##########################################

# Input and output file names
csv_file = path+"item.csv"
sql_file = path+"item.sql"

# Name of the MySQL table
table_name = 'item'

# Open the input CSV file
with open(csv_file, 'r', encoding='cp1252') as csvfile:
    csvreader = csv.reader(csvfile)

    # Open the output SQL file
    with open(sql_file, 'w') as sqlfile:

        # Iterate through the rows in the CSV
        for row in csvreader:
            # Assuming the first column is 'id', the second is 'column2', and so on
            if len(row) == 24:
                # Replace single quotes with escaped single quotes
                row = [value.replace("'", "\\'") for value in row]
                sql_statement = f"INSERT INTO {table_name} VALUES ('{row[0]}', '{row[1]}', '{row[2]}', '{row[3]}', '{row[4]}', '{row[5]}', '{row[6]}', '{row[7]}', '{row[8]}', '{row[9]}', '{row[10]}', '{row[11]}', '{row[12]}', '{row[13]}', '{row[14]}', '{row[15]}', '{row[16]}', '{row[17]}', '{row[18]}', '{row[19]}', '{row[20]}', '{row[21]}', '{row[22]}', '{row[23]}');"
                sqlfile.write(sql_statement + '\n')
            else:
                print(f"Skipping row with incorrect number of columns: {row}")

print(f"SQL statements written to {sql_file}")


############################################# Modifying USER FILE ##########################################

# Input and output file names
csv_file = path+"user.csv"
sql_file = path+"user.sql"

# Name of the MySQL table
table_name = 'user'

# Open the input CSV file
with open(csv_file, 'r', encoding='cp1252') as csvfile:
    csvreader = csv.reader(csvfile)

    # Open the output SQL file
    with open(sql_file, 'w') as sqlfile:

        # Iterate through the rows in the CSV
        for row in csvreader:
            # Assuming the first column is 'id', the second is 'column2', and so on
            if len(row) == 5:
                # Replace single quotes with escaped single quotes
                row = [value.replace("'", "\\'") for value in row]
                sql_statement = f"INSERT INTO {table_name} VALUES ('{row[0]}', '{row[1]}', '{row[2]}', '{row[3]}', '{row[4]}');"
                sqlfile.write(sql_statement + '\n')
            else:
                print(f"Skipping row with incorrect number of columns: {row}")

print(f"SQL statements written to {sql_file}")

############################################# Modifying DATA FILE ##########################################

# Input and output file names
csv_file = path+"data.csv"
sql_file = path+"data.sql"

# Name of the MySQL table
table_name = 'data0'

# Open the input CSV file
with open(csv_file, 'r', encoding='cp1252') as csvfile:
    csvreader = csv.reader(csvfile)

    # Open the output SQL file
    with open(sql_file, 'w') as sqlfile:

        # Iterate through the rows in the CSV
        for row in csvreader:
            # Assuming the first column is 'id', the second is 'column2', and so on
            if len(row) == 3:
                # Replace single quotes with escaped single quotes
                row = [value.replace("'", "\\'") for value in row]
                sql_statement = f"INSERT INTO {table_name} VALUES ('{row[0]}', '{row[1]}', '{row[2]}');"
                sqlfile.write(sql_statement + '\n')
            else:
                print(f"Skipping row with incorrect number of columns: {row}")

print(f"SQL statements written to {sql_file}")