# Find Student Support Services with AI Vector Search

## Introduction

Gilly Bourne is an AI engineer at Seer Higher Education. Her team has built a student-support search page for the student-success team. A student or support analyst can enter a need such as **help choosing courses and meeting an advisor**. The application should find relevant student-support services even when the service catalog uses different words.

Gilly already has student, service, and request data in the database, along with the service text used for embeddings. Her design problem is connecting a plain-language student need to those existing rows. She needs to create service vectors, rank the closest services by meaning, and join those matches to active student-service requests. A useful result must show more than a similarity score. It must give the student-success team service and student context they can review.

She could export the service descriptions and embeddings to a separate vector service. That would add a second copy of student-support text, another index to refresh, and another set of access rules to manage. Gilly wants the search to run where the underlying rows already live, so one SQL statement can compare meaning, join service matches to requests and students, and return a result for the application.

In this lab, you review Gilly's implementation from the embedding model to the final student-support review list. You see why Oracle AI Database fits the job: vector search finds relevant services, and SQL joins connect them to exact request and student data in the same database.

![gilly](images/gilly.png)

<details>
<summary><strong>Key terms: embedding, vector, vector distance, and semantic search</strong></summary>

> - An **embedding** is a numerical profile of what text means. In this lab, service descriptions are embedded so similar student-support needs sit near each other mathematically, even when the wording is different.
>
> - An **ONNX embedding model** is a portable machine-learning model saved in the Open Neural Network Exchange (ONNX) format. It turns text into a vector of numbers that captures meaning. Oracle AI Database can load and run this model inside the database, close to the service rows.
>
> - A **vector** is the stored numerical form of an embedding. Oracle Database can store vectors beside the service rows they describe, so the search stays connected to service names, academic programs, requests, and student context.
>
> - **Vector distance** measures how close two vectors are. A smaller distance means the meanings are more similar; a larger distance means they are farther apart. In this lab, distance helps rank which services best match a student's support need.
>
> - **Semantic search** means searching by meaning instead of exact words. A search for "help choosing courses and meeting an advisor" can find advising services even when the service names use different wording.

</details>

Gilly has already built the student-support search page. In this lab, you review how she built the service search. The search area lets a student or support analyst enter a need in ordinary language and receive ranked services by meaning.

### Objectives

- Check the embedding model Gilly needs for semantic search.
- Create service vectors inside the database.
- Review a semantic service search for a student-support need.
- Turn service matches into an active-request review list.
- Explain why vector search belongs beside student-support data and access controls.

Estimated Time: **10 minutes**

### Hands-on Scenario

| Step                | Student-success focus                                                                                                                  |
| ---------------------| --------------------------------------------------------------------------------------------------------------------------------------|
| Business Problem    | A student or support analyst needs to find relevant services without knowing the exact terms used in the service catalog.             |
| Technical Challenge | Gilly must search by meaning while keeping service data, vectors, requests, students, and access controls together.                  |
| Persona Focus       | You review Gilly's implementation as she explains how the search connects a student's need to services and active requests.          |
| What You Will See   | Vector search ranks services by meaning, then SQL adds request status, demand score, and student context.                              |
| Database Capability | `VECTOR_EMBEDDING`, vector columns, and `VECTOR_DISTANCE` run beside relational student-support data.                                 |
| Outcome             | The application can turn a plain-language need into a student-support review list without a separate vector database or copied text. |

Persona focus: You are reviewing the search tool Gilly built for student-success operations.


> **SQL Worksheet reminder:** Need a reminder on how to open and use the SQL Worksheet? Return to [Getting Started Task 2: Open SQL Worksheet](?lab=getting-started#Task2:OpenSQLWorksheet) for the step-by-step guide showing how to run SQL statements.


## Task 1: Check the embedding model

Start with Gilly's first design question: **what does similarity search need?** It needs vectors for the service descriptions being searched and an embedding model that converts a student's support need into a vector.

Gilly asks Jessica to make an ONNX embedding model available in Oracle AI Database. Oracle AI Database can store and run the model inside the database, so it can create the query embedding where the service embeddings already live. The application does not have to send student-support text to a separate service and bring the vector back.

1. Run the following query to see which embedding models are available:

    ```sql
    <copy>
    SELECT owner,
           model_name,
           algorithm,
           mining_function
    FROM all_mining_models
    WHERE mining_function = 'EMBEDDING'
    ORDER BY owner, model_name;
    </copy>
    ```

    **Expected output: Available Embedding Models**

    ![model](images/model.png)

    The result should include an embedding model owned by `ADMIN`, such as `ALL_MINILM_L12_V2`. This compact model turns text into 384-number vectors. The `EMBEDDING` value confirms that the model can turn a student's support need into a vector for similarity search.

2. Review what this means for Gilly's application.

    Gilly can call the model from SQL with `VECTOR_EMBEDDING(...)`. Jessica manages the model inside the database, while Gilly uses it in her service search query. The student-service data, `SERVICE_EMBEDDINGS`, and access controls stay in the same database.

    > **Note:** This is the key Oracle AI Database differentiator in this lab. The embedding model runs inside the database, so Gilly does not need a separate embedding service or a data pipeline to move student-support text between systems.

## Task 2: Create service vectors

Gilly creates the service vectors used for semantic search. Each service record has concise text describing one student-support service, giving the embedding model a focused meaning to compare with a student's support need.

1. Review the service text Gilly will embed:

    ```sql
    <copy>
    SELECT se.service_id,
           s.service_name,
           s.academic_program,
           se.embedding_text
    FROM service_embeddings se
    JOIN student_services_v s ON s.service_id = se.service_id
    FETCH FIRST 5 ROWS ONLY;
    </copy>
    ```

    The `EMBEDDING_TEXT` value gives the model a concise description of what the service provides. Gilly does not need to embed request status, demand scores, or other values that do not describe the service.

2. Create the service vectors inside Oracle Database:

    ```sql
    <copy>
    UPDATE service_embeddings
    SET embedding = VECTOR_EMBEDDING(
      ADMIN.ALL_MINILM_L12_V2 USING embedding_text AS DATA);
    </copy>
    ```

    The model reads the service text in each row and writes one vector back to that same row. The vector is stored beside the service identifier so Gilly can rank services and join the matches back to `STUDENT_SERVICES_V`.

3. Commit the new service vectors:

    ```sql
    <copy>
    COMMIT;
    </copy>
    ```

    The commit makes the generated vectors available to the later search steps.

4. Verify the service vectors and their dimensions:

    ```sql
    <copy>
    SELECT se.service_id,
           s.service_name,
           s.academic_program,
           VECTOR_DIMENSION_COUNT(se.embedding) AS dimensions,
           se.embedding
    FROM service_embeddings se
    JOIN student_services_v s ON s.service_id = se.service_id
    FETCH FIRST 5 ROWS ONLY;
    </copy>
    ```

    ![vector](images/vector.png)

    Each service now has its own 384-dimensional vector. Gilly can compare a student's support need with these stored vectors and use the ranked services in the application.

    > **Note:** Chunking is not relevant for this data. Each row describes one short student-support service, so splitting it would create several vectors for one service without adding useful detail. Chunking becomes useful for long documents, such as policies or advising guides, where each section may answer a different question.

## Task 3: Test the service vectors

Now Gilly tests the service vectors with a simple semantic query. She asks for services related to **help choosing courses and meeting an advisor** and lets the database rank them by meaning.

1. Run the following query:

    The SQL creates an embedding for the phrase `help choosing courses and meeting an advisor`, compares it with the vectors in `SERVICE_EMBEDDINGS.EMBEDDING`, and returns the cosine distance. A smaller distance means the two vectors are closer in meaning, so the query orders the smallest distance first.

    <details>
    <summary><strong>Why this matters to Gilly</strong></summary>

    > Gilly could export the text to an external embedding pipeline or search service. That would create extra copies of student-support text and make it harder to show which service descriptions the application searched.
    >
    > Oracle AI Vector Search keeps the service catalog, vectors, SQL query, and vector distance with the student-support data. Gilly can check the search and use the result in the application without adding another data store.

    </details>

    ```sql
    <copy>
    SELECT s.service_name,
           s.academic_program,
           VECTOR_DISTANCE(
             se.embedding,
             VECTOR_EMBEDDING(ADMIN.ALL_MINILM_L12_V2 USING 'help choosing courses and meeting an advisor' AS DATA),
             COSINE) AS vector_distance
    FROM service_embeddings se
    JOIN student_services_v s ON s.service_id = se.service_id
    ORDER BY vector_distance
    FETCH FIRST 3 ROWS ONLY;
    </copy>
    ```

    **Expected output: Student-Support Service Matches**

    ![result](images/result.png)

2. Review the ranked services.
    The query embeds the student's phrase at runtime and compares it to the `SERVICE_EMBEDDINGS.EMBEDDING` column. `VECTOR_DISTANCE` calculates the distance between the two vectors using the `COSINE` metric. A lower value means a closer match.

    In the broader workflow, these ranked services become candidates for support-team review alongside the student's current request and circumstances.

3. Show the result as a similarity score:

    Vector distance is useful for checking the search, but business users may not know what a cosine distance means. Gilly changes the display to a similarity score. She subtracts the distance from `1`, so a higher score means a closer match, and rounds the result to four decimal places.

    ```sql
    <copy>
    SELECT s.service_name,
           s.academic_program,
           ROUND(1 - VECTOR_DISTANCE(
             se.embedding,
             VECTOR_EMBEDDING(ADMIN.ALL_MINILM_L12_V2 USING 'help choosing courses and meeting an advisor' AS DATA),
             COSINE), 4) AS similarity
    FROM service_embeddings se
    JOIN student_services_v s ON s.service_id = se.service_id
    ORDER BY similarity DESC
    FETCH FIRST 3 ROWS ONLY;
    </copy>
    ```

    The query uses the same vectors and the same cosine calculation. It only changes how the result is shown to the person using the application.

    ![result2](images/result2.png)

## Task 4: Find student requests related to a support need

Gilly now has the business requirement for the application. A support analyst should be able to enter a student's need and find active student-service requests related to matching services. The result gives the student-success team a short list for review, with the service match, request status, demand score, and student context.

1. Run the following query for the need `help choosing courses and meeting an advisor`:

    ```sql
    <copy>
    WITH matched_services AS (
        SELECT se.service_id,
               sv.service_name,
               sv.academic_program,
               ROUND(1 - VECTOR_DISTANCE(
                 se.embedding,
                 VECTOR_EMBEDDING(
                   ADMIN.ALL_MINILM_L12_V2
                   USING 'help choosing courses and meeting an advisor' AS DATA
                 ),
                 COSINE), 4) AS similarity
        FROM service_embeddings se
        JOIN student_services_v sv ON sv.service_id = se.service_id
        ORDER BY similarity DESC
        FETCH FIRST 3 ROWS ONLY
    )
    SELECT ms.service_name,
           ms.academic_program,
           ms.similarity,
           r.request_id,
           r.request_status,
           r.demand_score,
           s.first_name || ' ' || s.last_name AS student
    FROM matched_services ms
    JOIN student_request_lines l ON l.service_id = ms.service_id
    JOIN student_service_requests r ON r.request_id = l.request_id
    JOIN highered_students_v s ON s.student_id = r.student_id
    WHERE r.request_status IN ('OPEN', 'IN_PROGRESS')
    ORDER BY ms.similarity DESC,
             r.demand_score DESC;
    </copy>
    ```

    The first part ranks services by meaning. The remaining joins use ordinary relational keys to find active requests, the students who submitted them, and the demand evidence that helps staff decide what to review first.

    **Expected output: Student-Support Review List**

    The result shows active requests connected to services related to the student's need. The similarity score explains why the service was included, while the request, status, demand, and student columns give the support team enough information to decide what to review next.


    ![result3](images/result3.png)

2. Review the business result.

    Gilly does not vectorize every request or student. She vectorizes the service descriptions once, then builds a converged query that combines vector search with SQL joins for exact request and student context. This keeps the search flexible while the final review list remains precise and easy to act on.

## Conclusion

Gilly has built the search behind the application and connected it to a student-support decision. A student's plain-language need can produce ranked services and an active-request review list using vectors, relational joins, and SQL in Oracle AI Database. The similarity score helps staff find candidates to review; it does not assign a service automatically. Student context, request status, demand score, and service evidence still belong in the human decision.

## Acknowledgements

* **Author** - Pat Shepherd
* **Last Updated By/Date** - Pat Shepherd, September 2026
