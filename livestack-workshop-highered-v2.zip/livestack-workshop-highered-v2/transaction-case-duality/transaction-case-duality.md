# Build a JSON Application Model

## Introduction

Thomas Brune is an application developer at Seer Higher Education. He and his team are building a new web and mobile application for students. The team wants a faster student experience, with fewer round trips and payloads that match the screens and support services they are building.

Thomas needs student-service request data as a JSON payload that a web or mobile application can consume directly. One payload can group the student ID, request status, demand score, requested services, and optional app-specific attributes. JSON lets him evolve that payload as the application changes. The data already lives in Oracle AI Database, so his question is how to use JSON without giving up relational keys, SQL, transactions, and database controls.

Thomas asks Jessica, the DBA, to walk through three ways to work with JSON in Oracle AI Database. They start with a JSON value in a relational table, then a collection of JSON documents, and finally a JSON Relational Duality View over existing relational rows. The goal is to choose the right approach for each application feature without creating a second copy of student-service data.

![thomas](images/thomas.png)

<details>
<summary><strong>Key terms: JSON columns, JSON collections, and JSON Relational Duality</strong></summary>

> - A **JSON column** stores a JSON value in a relational table alongside normal typed columns, keys, and constraints. Thomas can use it for optional or changing application attributes without turning every new attribute into a schema change.
>
> - A **JSON collection** is a special table or view that provides a set of JSON documents through one `JSON`-typed `DATA` column. Each document can have a top-level `_id` used to identify it.
>
> - **JSON Relational Duality** lets Oracle Database expose relational data as JSON documents without copying it into a separate document database. The application gets the document shape Thomas wants for its API. The database keeps the relational rows and controls.
>

</details>

Thomas's application needs a payload with the student-service request and its requested services together, such as this:

```json
{
  "_id": 1001,
  "studentId": 101,
  "requestStatus": "OPEN",
  "demandScore": 92,
  "services": [
    { "requestLineId": 1, "serviceId": 11, "serviceName": "First-Year Advising" }
  ]
}
```

The application uses this document shape, while the database keeps the student-service request and request lines in relational form. In this lab, you build and read this type of payload in three ways.

### Objectives

- Store flexible student-support application attributes as JSON in a relational table.
- Create and query a JSON Collection Table of student-service request documents.
- Read and update relational student-service request data through `STUDENT_SERVICE_REQUESTS_DV`.
- Compare the three JSON approaches and choose the right one for an application feature.

Estimated Time: **10 minutes**

### Hands-on Scenario

| Step | Student-success focus |
| --- | --- |
| Business Problem | Thomas's team needs flexible JSON payloads for a new student-support web and mobile application. |
| Technical Challenge | The team needs application-friendly request documents while the database keeps relational keys, joins, and controls. |
| Persona Focus | Thomas tests JSON storage, collections, and duality with Jessica's database guidance. |
| What You Will See | One Oracle AI Database supports several JSON access patterns over student-service data. |
| Database Capability | Native JSON, SQL/JSON functions, and JSON Relational Duality work together. |
| Outcome | Thomas can choose an application shape without creating a second student-service data store. |

Persona focus: You are Thomas, working with Jessica to decide how the new application should store, assemble, and read student-service request data.

### Thomas's three JSON choices

Thomas does not need one JSON pattern for every feature. A JSON column holds optional application attributes in a relational table. A JSON Collection Table holds documents owned by the application. A duality view assembles a document from existing relational tables. Thomas uses the document shape in the application, while Jessica works with the underlying request rows using SQL.

This keeps the student-service request in one database and avoids complex, expensive integration between separate systems. Thomas gets the document shape his application needs, and Jessica keeps the relational rows, SQL access, and database controls.

> **SQL Worksheet reminder:** Need a reminder on how to open and use the SQL Worksheet? Return to [Getting Started Task 2: Open SQL Worksheet](?lab=getting-started#Task2:OpenSQLWorksheet) for the step-by-step guide on how to run SQL statements.

## Task 1: Store flexible application data as JSON

Thomas starts with data that belongs to the application but does not need its own relational columns. The workshop database already contains the student-service request rows. He adds a small application-data table with a native `JSON` column for optional screen and student-experience settings.

1. Create the application-data table and add one sample payload.

    ```sql
    <copy>
    CREATE TABLE thomas_app_data (
        request_id NUMBER PRIMARY KEY,
        app_data   JSON NOT NULL
    );

    INSERT INTO thomas_app_data (request_id, app_data)
    SELECT request_id,
           JSON_OBJECT(
               'screen'          VALUE 'student-request-detail',
               'showDemandScore' VALUE 'true' FORMAT JSON,
               'features'        VALUE JSON_ARRAY('live-status', 'advisor-notes')
               RETURNING JSON
           )
    FROM (
        SELECT request_id
        FROM student_service_requests
        ORDER BY request_id
        FETCH FIRST 1 ROW ONLY
    );

    COMMIT;
    </copy>
    ```

2. Read values from the JSON column.

    ```sql
    <copy>
    SELECT request_id,
           JSON_VALUE(app_data, '$.screen') AS screen_name,
           JSON_VALUE(app_data, '$.showDemandScore' RETURNING BOOLEAN) AS show_demand_score,
           JSON_QUERY(app_data, '$.features') AS app_features
    FROM thomas_app_data;
    </copy>
    ```

    `REQUEST_ID` remains a relational key. `APP_DATA` can change as the application changes. Thomas can query both with SQL in one table.

## Task 2: Create a JSON Collection Table

Thomas now needs a collection of student-service request documents. Unlike the JSON column in Task 1, this object is a JSON Collection Table: each row is a document, the document is stored in `DATA`, and `_id` identifies the document.

1. Create the collection and add the sample student-service request document.

    ```sql
    <copy>
    CREATE JSON COLLECTION TABLE thomas_student_request_docs
    WITH ETAG;

    INSERT INTO thomas_student_request_docs (data)
    SELECT JSON_OBJECT(
               '_id'          VALUE r.request_id,
               'studentId'    VALUE r.student_id,
               'requestStatus' VALUE r.request_status,
               'demandScore'  VALUE r.demand_score,
               'services'     VALUE (
                   SELECT JSON_ARRAYAGG(
                              JSON_OBJECT(
                                  'requestLineId' VALUE l.request_line_id,
                                  'serviceId'     VALUE l.service_id,
                                  'serviceName'   VALUE l.service_name
                                  RETURNING JSON
                              ) ORDER BY l.request_line_id RETURNING JSON
                          )
                   FROM student_request_lines l
                   WHERE l.request_id = r.request_id
               ) FORMAT JSON
               RETURNING JSON
           )
    FROM student_service_requests r
    JOIN thomas_app_data t ON t.request_id = r.request_id;

    COMMIT;
    </copy>
    ```

    `WITH ETAG` adds an `_metadata.etag` value to each document. Oracle changes the tag whenever the document changes. Thomas's application can send the tag it last read when it updates a document. If the tag no longer matches, the application knows that someone else changed the document first and can avoid overwriting the newer version. This protects student-service data when web and mobile requests try updating the same document at the same time.

2. Query the collection as documents.

    ```sql
    <copy>
    SELECT JSON_SERIALIZE(data PRETTY) AS request_document
    FROM thomas_student_request_docs
    WHERE JSON_VALUE(data, '$._id' RETURNING NUMBER) =
          (SELECT request_id FROM thomas_app_data);
    </copy>
    ```

    ![SQL Worksheet showing the student-service request document returned from the JSON collection](images/task2-step2-json-collection-result.png " ")

    Thomas now has a document collection that a document API can access, and SQL can query the same `DATA` column. The collection stores the documents; it is separate from the relational `STUDENT_SERVICE_REQUESTS` and `STUDENT_REQUEST_LINES` tables.

## Task 3: Read a customer document from relational data

Thomas now tests the document shape his application can consume directly.

1. Run this query:



    This query selects the JSON `DATA` column from `STUDENT_SERVICE_REQUESTS_DV` so Thomas can inspect the student-service request document shape in SQL Worksheet.

    <details>
    <summary><strong>Why this matters to Thomas</strong></summary>

    > Thomas can use a JSON Collection Table when the application owns the document. But the transaction already has relational tables that Jessica and other teams rely on.
    > The duality view gives Thomas a document over those existing rows. He can choose the application shape without copying the transaction into another store.

    </details>

    ```sql
    <copy>
    SELECT data AS request_document
    FROM student_service_requests_dv
    FETCH FIRST 1 ROW ONLY;
    </copy>
    ```

    **Expected output:**

    ![SQL Worksheet showing the transaction document returned by the duality view](images/jsondv-result.png " ")

2. Expand the document in SQL Worksheet.
    The query reads the duality view as a document source. Oracle constructs the JSON shape from relational data, so the application gets a student-service request payload without a second copy of the request record.

    The \_id value appears in the JSON document while the source data remains relational. The payload includes `studentId`, `requestStatus`, `demandScore`, and nested requested services. The application gets these fields without a second student-service request store.

    The same student-service request now has two useful forms: API-ready JSON for the application and relational rows for analysis.

    > **Note:** Look for `_metadata.etag` in the document. The ETAG changes when the document changes, so Thomas's application can detect a newer version before updating the request and avoid overwriting another advisor or support team's change.

## Task 4: Enable document inserts and updates

The existing `STUDENT_SERVICE_REQUESTS_DV` lets an application update an existing student-service request document. In this task, you extend that contract so the application can also create one. The database continues to control the relational tables, keys, and constraints. The duality view can also act as a security boundary. Thomas's application receives only the document fields and write operations exposed by the view, without direct access to the underlying tables.

1. Check the current document-write capabilities.

    ```sql
    <copy>
    SELECT view_name,
           allow_insert,
           allow_update,
           allow_delete
    FROM user_json_duality_views
    WHERE view_name = 'STUDENT_SERVICE_REQUESTS_DV';
    </copy>
    ```

    **Expected output: Current Document Capabilities**

    ![json contract](images/jsondv-contract.png)

    The view currently allows updates but not new top-level documents. The root `STUDENT_SERVICE_REQUESTS` table controls document insertion. The nested `STUDENT_REQUEST_LINES` rows must also allow inserts so the document can include requested services.

2. Enable insert and update for the request document and its nested request lines.

    You are changing the duality-view contract, not creating a second API store. The two `WITH INSERT UPDATE` clauses let Oracle map permitted JSON writes to `STUDENT_SERVICE_REQUESTS` and `STUDENT_REQUEST_LINES` while preserving keys, foreign keys, data types, and other constraints. The `serviceId` field maps each JSON request line to `STUDENT_REQUEST_LINES.SERVICE_ID`.

    ```sql
    <copy>
    CREATE OR REPLACE JSON RELATIONAL DUALITY VIEW student_service_requests_dv AS
    SELECT JSON {
        '_id'           : r.request_id,
        'studentId'     : r.student_id,
        'requestStatus' : r.request_status,
        'demandScore'   : r.demand_score,
        'services' : [
            SELECT JSON {
                'requestLineId' : l.request_line_id,
                'serviceId'     : l.service_id,
                'serviceName'   : l.service_name
            }
            FROM student_request_lines l WITH INSERT UPDATE
            WHERE l.request_id = r.request_id
        ]
    }
    FROM student_service_requests r WITH INSERT UPDATE;
    </copy>
    ```

    This duality view uses two relational tables. `STUDENT_SERVICE_REQUESTS` provides the document root. Related `STUDENT_REQUEST_LINES` rows become the nested `services` collection. The `WITH INSERT UPDATE` clauses let Thomas write a complete student-service request document while Oracle maintains the rows and relationships.

    **Expected output: View Definition Updated**

    Oracle created or replaced the duality view. Verify the new capabilities in the next step.

3. Run the capability query again.

    ```sql
    <copy>
    SELECT view_name,
           allow_insert,
           allow_update,
           allow_delete
    FROM user_json_duality_views
    WHERE view_name = 'STUDENT_SERVICE_REQUESTS_DV';
    </copy>
    ```

    **Expected output: Document Capabilities Enabled**

    ![insert json](images/jsondv-insert.png)

    The view can now receive a new JSON student-service request document and apply a document update. Thomas has a document API over the existing relational student-support data. He can use it for a student feature such as submitting a new advising or support request. The application sends one document, and the database writes the request and its nested request lines to the relational tables.

## Task 5: Create and update a student-service request

Now create one nested student-service request document, inspect the relational rows Oracle creates, and update the request status through the same JSON Relational Duality View.

> **Workshop data boundary:** This task commits reserved request `900001` and request line `990001`. They remain in the current workshop schema until it is reset. The rerun guard prevents a duplicate request, and no seeded request is overwritten.

1. Insert the reserved HE request document.

    The document uses student `103`, Priya Shah, and service `13`, Tutoring Appointment. The demand score is `76`, below the existing score for that service, so the maximum service-demand score does not change.

    `SELECT ... FROM dual` generates one candidate JSON document without reading an application table. Keep `FROM dual` because `WHERE NOT EXISTS` evaluates the rerun guard for that one candidate row.

    ```sql
    <copy>
    INSERT INTO student_service_requests_dv (data)
    SELECT JSON(
      '{
        "_id": 900001,
        "studentId": 103,
        "requestStatus": "OPEN",
        "demandScore": 76,
        "services": [
          {
            "requestLineId": 990001,
            "serviceId": 13,
            "serviceName": "Tutoring Appointment"
          }
        ]
      }'
    )
    FROM dual
    WHERE NOT EXISTS (
      SELECT 1
      FROM student_service_requests
      WHERE request_id = 900001
    );
    </copy>
    ```

    **Expected output: Request Document Inserted**

    Oracle inserts one document. If reserved request `900001` already exists, the rerun guard safely inserts zero rows.

2. Commit the insert as its own SQL Worksheet action.

    In Database Actions SQL Worksheet, highlight this command and run it explicitly. `COMMIT` makes the new request visible to later statements and other worksheet connections.

    ```sql
    <copy>
    COMMIT;
    </copy>
    ```

    **Expected output: Commit Complete**

    Oracle reports `Commit complete.`

3. Verify that the JSON document created relational rows.

    This query reads `STUDENT_SERVICE_REQUESTS`, `STUDENTS`, and `STUDENT_REQUEST_LINES` directly. It verifies that the application-shaped document created one relational request row and one related request line.

    ```sql
    <copy>
    SELECT r.request_id AS "Request",
           r.request_status AS "Status",
           s.first_name || ' ' || s.last_name AS "Student",
           r.demand_score AS "Demand Score",
           l.request_line_id AS "Request Line",
           l.service_id AS "Service ID",
           l.service_name AS "Service Name"
    FROM student_service_requests r
    JOIN students s ON s.student_id = r.student_id
    JOIN student_request_lines l ON l.request_id = r.request_id
    WHERE r.request_id = 900001;
    </copy>
    ```

    **Expected output: Inserted Request as Relational Rows**

    | Request | Status | Student | Demand Score | Request Line | Service ID | Service Name |
    | ---: | --- | --- | ---: | ---: | ---: | --- |
    | 900001 | OPEN | Priya Shah | 76 | 990001 | 13 | Tutoring Appointment |

4. Update the document status through `STUDENT_SERVICE_REQUESTS_DV`.

    `JSON_TRANSFORM` changes only `requestStatus`. Oracle maps that field to `STUDENT_SERVICE_REQUESTS.REQUEST_STATUS`; no application-side JSON parsing, second request copy, or synchronization job is required.

    ```sql
    <copy>
    UPDATE student_service_requests_dv
    SET data = JSON_TRANSFORM(data, SET '$.requestStatus' = 'IN_PROGRESS')
    WHERE JSON_VALUE(data, '$._id' RETURNING NUMBER) = 900001;
    </copy>
    ```

    **Expected output: Request Status Updated**

    Oracle updates one document.

5. Commit the status update as its own SQL Worksheet action.

    Highlight and run this command explicitly before you verify the update.

    ```sql
    <copy>
    COMMIT;
    </copy>
    ```

    **Expected output: Commit Complete**

    Oracle reports `Commit complete.`

6. Verify the relational status update.

    Run this query after the commit. It reads the request and request-line rows directly, so you can see that the JSON update changed the request status while keeping the student, demand score, and service evidence intact.

    ```sql
    <copy>
    SELECT r.request_id AS "Request",
           r.request_status AS "Status",
           s.first_name || ' ' || s.last_name AS "Student",
           r.demand_score AS "Demand Score",
           l.request_line_id AS "Request Line",
           l.service_id AS "Service ID",
           l.service_name AS "Service Name"
    FROM student_service_requests r
    JOIN students s ON s.student_id = r.student_id
    JOIN student_request_lines l ON l.request_id = r.request_id
    WHERE r.request_id = 900001;
    </copy>
    ```

    **Expected output: Updated Request as Relational Rows**

    | Request | Status | Student | Demand Score | Request Line | Service ID | Service Name |
    | ---: | --- | --- | ---: | ---: | ---: | --- |
    | 900001 | IN_PROGRESS | Priya Shah | 76 | 990001 | 13 | Tutoring Appointment |

7. 🎯 **Interactive challenge: explain the relational change.**

    Use the result you just returned. Which relational column changed because the JSON update targeted only `requestStatus`? Which request and service values stayed the same?

    <details>
    <summary><strong>Challenge answer: one document, one governed request</strong></summary>

    **Expected output: One Status Change, Stable Request Line**

    The relational request status changes. The demand score remains `76`, and the request line remains `990001 | 13 | Tutoring Appointment` because the JSON update did not change those fields.

    > `STUDENT_SERVICE_REQUESTS.REQUEST_STATUS` changes from `OPEN` to `IN_PROGRESS`. The related `STUDENT_REQUEST_LINES` row remains unchanged. The application and student-success analyst use two access shapes over the same governed request, so Oracle Database does not need to reconcile a document copy with a relational copy.

    </details>

## Task 6: Project JSON fields with SQL

Thomas has confirmed that the application can display and update the request document. Jessica now checks the same student-service request with SQL before the feature goes live. She uses the relational tables for normal reporting and analysis. Here, she queries `STUDENT_SERVICE_REQUESTS_DV` to verify the exact JSON contract that Thomas's application receives. She can also project fields from the document to test student-support searches and status filters. In this context, "project" means pulling selected values out of the JSON document and displaying them as SQL result columns.

1. Run this SQL/JSON projection query:

    Thomas's request document is still available for SQL analysis. The same student-service request shape can be queried, filtered, and joined to relational student data.

    The SQL uses `JSON_VALUE` to extract request fields from the duality document. That is the projection step. It returns the request ID, status, student ID, and demand score, then joins the student ID to `STUDENTS` so Jessica can review a readable student name alongside the document values.

    Thomas does not need to hand-build this document in the application or copy the request to a separate document store. The application gets JSON, while Jessica still has SQL access to the same student-service request rows.

    ```sql
    <copy>
    SELECT JSON_VALUE(rd.data, '$._id' RETURNING NUMBER) AS request_id,
           JSON_VALUE(rd.data, '$.requestStatus') AS request_status,
           JSON_VALUE(rd.data, '$.studentId' RETURNING NUMBER) AS student_id,
           s.first_name || ' ' || s.last_name AS student,
           JSON_VALUE(rd.data, '$.demandScore' RETURNING NUMBER) AS demand_score
    FROM student_service_requests_dv rd
    JOIN students s
      ON s.student_id = JSON_VALUE(rd.data, '$.studentId' RETURNING NUMBER)
    WHERE JSON_VALUE(rd.data, '$._id' RETURNING NUMBER) = 900001;
    </copy>
    ```

    **Expected output: JSON Field Projection**

    ![project json](images/json-project.png)

2. Run the equivalent query against the relational tables.

    ```sql
    <copy>
    SELECT r.request_id AS request_id,
           r.request_status AS request_status,
           r.student_id AS student_id,
           s.first_name || ' ' || s.last_name AS student,
           r.demand_score AS demand_score
    FROM student_service_requests r
    JOIN students s
      ON s.student_id = r.student_id
    WHERE r.request_id = 900001;
    </copy>
    ```

    ![project relational](images/json-relational.png)

    Compare the result with the previous query. The request ID, status, student, and demand score should match. Thomas's application is reading the JSON document, while Jessica's relational query reads the underlying rows.

## Conclusion: Choose the right JSON approach

Thomas does not have to choose one JSON model for the whole application. He can choose based on who owns the data and whether the application needs a document over existing relational rows.

| Approach                          | Use it when                                                                                 | Example in Thomas's application                                                                            | Where the data lives                                                                                           |
| -----------------------------------| ---------------------------------------------------------------------------------------------| ------------------------------------------------------------------------------------------------------------| ----------------------------------------------------------------------------------------------------------------|
| JSON column in a relational table | A relational record needs optional or changing attributes.                                  | Store screen settings or student-support app options alongside a request key.                              | A normal relational table with a native `JSON` column.                                                         |
| JSON Collection Table             | The application owns a set of JSON documents and needs document-style access.               | Store student-service request documents whose app attributes can change over time.                         | A JSON Collection Table with one document in each `DATA` row.                                                  |
| JSON Relational Duality View      | The data already belongs in relational tables, but the application needs one JSON document. | Return a student-service request with its status, demand score, and services, or accept a new request document from the app. | Relational tables such as `STUDENT_SERVICE_REQUESTS` and `STUDENT_REQUEST_LINES`; the duality view defines the JSON shape for Thomas's app. |

For Thomas, `STUDENT_SERVICE_REQUESTS_DV` is the right choice for the student-support feature because `STUDENT_SERVICE_REQUESTS` and `STUDENT_REQUEST_LINES` already hold governed HE data. The application gets the JSON payload it needs, while Jessica keeps SQL, relational constraints, and controlled access to the same request data.


## Acknowledgements

* **Author** - Pat Shepherd
* **Last Updated By/Date** - Pat Shepherd, September 2026
