# Build Student Success Intelligence with Oracle AI Database

## Introduction

Jessica Chan is the database administrator at Seer Higher Education. Her teams are building student-support applications, improving student-success reviews, coordinating campus services, and adding AI to support operations.

The requests look different, but they share one problem. The data is already in Oracle AI Database, and each team wants to use it in a different way:

- Thomas needs student requests as JSON for a web and mobile application.
- Gilly needs semantic search that can find support services by meaning, not only by matching words.
- Bob needs to follow relationships between students, advisors, programs, and services to coordinate support.
- Moon needs to calculate distances between students, campus service sites, and service regions.
- Otto needs to train and score a student-service demand model.
- Nina needs to ask student-success questions in plain language and turn the answers into a useful review.

![team](images/team.png)

Jessica's job is to help each team meet its requirement without creating a new data copy or a separate security model for every feature. She uses Oracle AI Database as the shared foundation: relational tables remain the source for student and service records, while JSON, vectors, graphs, spatial data, machine learning, and AI services work with those same records.

This workshop follows Jessica and her colleagues as they coordinate student support at Seer Higher Education. Each lab focuses on one student-success requirement, but the database remains the common thread. You will see how the teams use different data types and database capabilities together, and how Jessica keeps access, SQL, and results visible.

### What the team builds

| Team member                   | Requirement                                                     | What you will see                                                                                                                          |
| -------------------------------| -----------------------------------------------------------------| --------------------------------------------------------------------------------------------------------------------------------------------|
| Jessica, DBA                  | Build the query behind a student-success command center.       | One SQL result combines student and service data, semantic service matching, JSON request data, and location context.                      |
| Thomas, application developer | Give the application flexible student-request documents.       | JSON columns, JSON collections, and JSON Relational Duality Views provide different ways to serve application data.                        |
| Gilly, AI engineer            | Find services related to a student's expressed need.            | Jessica loads an embedding model into the database, and Gilly creates vectors where the student-support data already lives.                |
| Bob, graph specialist         | Find connected students, advisors, programs, and services.     | A property graph uses the existing relational data to show support paths that become difficult to manage with repeated SQL joins.          |
| Moon, spatial expert          | Route students to nearby campus service sites.                  | The database calculates distance from geographic data that the application can also display.                                               |
| Otto, data scientist          | Identify services that may face a demand surge.                 | Oracle Machine Learning trains and scores a model inside the database, close to the service and activity data.                            |
| Nina, student-success analyst | Ask student-success questions without writing every query.      | Select AI generates SQL that Nina can inspect, run, and refine. Select AI Agent adds a restricted SQL tool and records the agent activity. |


The point is not to use every capability in every query. The point is that Jessica does not have to move the data into a separate database whenever a requirement changes. The same student-success records can support:

- An application payload.
- A vector search.
- A graph investigation.
- A spatial calculation.
- A model score.
- A natural-language question.

<details>
<summary><strong>Learn more: What does "converged database" mean?</strong></summary>

> A converged database supports different data types and workloads on one database foundation. In this workshop, that includes relational rows, JSON documents, vectors, graphs, geographic data, machine learning models, and AI-assisted SQL.
>
> The advantage is practical. Teams can use the data in the form their application or analysis needs while keeping the records, privileges, and SQL access connected. They do not need to copy student and service data into a document store, vector service, graph database, mapping system, or separate scoring service for each requirement.

</details>


### Objectives

- Follow Jessica and her team as they solve different student-success application and analysis requirements.
- Use relational SQL, JSON, vectors, graphs, spatial data, Oracle Machine Learning, Select AI, and Select AI Agent in practical tasks.
- See how one Oracle AI Database can support different data types without separate copies of the student-success records.
- Understand how database privileges, restricted AI profiles, approved tools, and execution history keep AI-assisted work visible and controlled.
- Connect the database work to the customer-facing Seer Higher Education student-success LiveStack demo.

Estimated Workshop Time: **90 minutes**

## Acknowledgements

* **Author** - Pat Shepherd
* **Last Updated By/Date** - Pat Shepherd, September 2026
