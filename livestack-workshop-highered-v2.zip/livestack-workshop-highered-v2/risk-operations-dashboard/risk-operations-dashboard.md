# Build a Converged Student-Success Dashboard Query

## Introduction

Jessica Chan is the database administrator responsible for keeping Seer Higher Education's student-support data reliable and useful. Every morning, the student-success operations team asks her a familiar question: **which student-service requests need attention first, and what service context should staff review before following up?**

Jessica can see the answer taking shape in the Student Success Dashboard, but the supporting data is spread across different forms. Request status and demand scores are relational rows. Student-service request details are available as JSON documents. The AI engineering team has also prepared vector representations of service descriptions for another use case. Student and campus-service locations are stored as spatial data. The data is connected by business meaning, but that does not automatically make the investigation easy to query.

In the past, Jessica might have had to maintain reporting extracts, coordinate a search index, ask an application team for request data, and reconcile a separate map or service-capacity system. That creates more copies of sensitive student-support data, more security boundaries, and more opportunities for the dashboard answer and the operational detail to disagree. Her challenge is not simply finding another database feature. It is giving the student-success team one answer they can trace back to the same governed data.

Jessica sees an opportunity in Oracle AI Database's converged architecture. A converged database lets one governed database support different data models and workloads together. Relational tables and views remain the foundation, while JSON documents, vectors, spatial geometry, graphs, machine-learning, and graph results can be queried alongside them. This means Jessica can answer a question that crosses those data types without complex and expensive integration across separate systems.

In this lab, you take Jessica's role as the DBA. You will write the converged SQL query behind the Student Success Dashboard. It combines relational request data, vector search, JSON student-service data, and spatial campus-service data in one Oracle AI Database, without separate systems or data copies.

![jessica](images/jessica.png)

### Objectives

- Explain what Oracle AI Database convergence means in a student-success review workflow.
- Run one query that combines relational, vector, JSON, and spatial database capabilities.
- Modify the query to investigate a different student-support question and explain the change in results.

Estimated Time: **10 minutes**

### Hands-on Scenario

| Step                | Student-success focus                                                                                         |
| ---------------------| ----------------------------------------------------------------------------------------------------------------|
| Business Problem    | Student-success teams need a quick way to find high-demand requests, related services, and campus context.    |
| Technical Challenge | The answer crosses request records, service meaning, JSON request data, and campus-service geography.         |
| Persona Focus       | Jessica Chan, the DBA, builds the query that gives staff this dashboard view.                                 |
| What You Will Do    | Use a single SQL statement that combines several data types.                                                   |
| Database Capability | Relational SQL, AI Vector Search, JSON Relational Duality, and Oracle Spatial work together.                   |
| Outcome             | The learner can explain convergence through a useful student-success result rather than a feature list.       |

Persona focus: You are Jessica Chan, the DBA. Your job is to build one governed query that gives student-success staff a connected view of requests, services, and campus operations.

> **SQL Worksheet reminder:** Need a reminder on how to open and use the SQL Worksheet? Return to [Getting Started Task 2: Open SQL Worksheet](?lab=getting-started#Task2:OpenSQLWorksheet) for the step-by-step guide showing how to run SQL statements.

## Task 1: Run a converged student-success investigation

The dashboard is a starting point for the decision, not the decision itself. Run the query below to produce a compact review of higher-demand student-service requests.

The query intentionally crosses four data models:

- **Relational:** `STUDENT_SERVICE_REQUESTS_V`, `HIGHERED_STUDENTS_V`, and `STUDENT_REQUEST_LINES_V` identify students, requested services, statuses, and demand scores.
- **Vector:** `SERVICE_EMBEDDINGS` and `VECTOR_DISTANCE` find services related by meaning to a student-support phrase.
- **JSON:** `STUDENT_SERVICE_REQUESTS_DV` is read as a document, and `JSON_TABLE` projects its nested services into rows so the request document can be counted.
- **Spatial:** `SDO_GEOM.SDO_DISTANCE` finds the closest active campus service site to each student's location.

    These are four operations in one investigation. Every row combines student-service demand, semantic relevance, the JSON request shape, and campus-service location context.

1. Open SQL Worksheet as `LLUSER`. 

2. Run the query (note the comments that help to locate the specific use of different data types):

    ```sql
    <copy>
    -- RELATIONAL DATA: identify higher-demand student-service requests
    -- and add the student and requested-service names.
    -- The demand-score filter keeps the review list focused on requests
    -- that need earlier attention.
    WITH request_context AS (
        SELECT r.request_id,
               r.student_id,
               s.first_name || ' ' || s.last_name AS student,
               r.request_status,
               r.demand_score,
               l.service_id,
               l.service_name
        FROM student_service_requests_v r
        JOIN highered_students_v s
          ON s.student_id = r.student_id
        JOIN student_request_lines_v l
          ON l.request_id = r.request_id
        WHERE r.demand_score >= 70
    ),
    -- VECTOR DATA: compare the support question with stored service
    -- embeddings to rank services by meaning, not exact wording.
    -- The service ID lets the semantic result join back to each request.
    semantic_match AS (
        SELECT se.service_id,
               ROUND(1 - VECTOR_DISTANCE(
                   se.embedding,
                   VECTOR_EMBEDDING(
                       ADMIN.ALL_MINILM_L12_V2
                       USING 'student support need requiring early review' AS DATA
                   ),
                   COSINE
               ), 4) AS semantic_similarity
        FROM service_embeddings se
    ),
    -- JSON DATA: read student-service request documents and count the
    -- nested services exposed through the JSON Relational Duality View.
    -- JSON_TABLE turns the nested services array into rows that SQL can count.
    json_request_activity AS (
        SELECT jt.request_id,
               COUNT(jt.request_line_id) AS json_service_count
        FROM student_service_requests_dv r
        CROSS APPLY JSON_TABLE(
            r.data,
            '$'
            COLUMNS (
                request_id NUMBER PATH '$._id',
                NESTED PATH '$.services[*]' COLUMNS (
                    request_line_id NUMBER PATH '$.requestLineId'
                )
            )
        ) jt
        GROUP BY jt.request_id
    ),
    -- SPATIAL DATA: find the closest active campus service site for each
    -- student's location.
    -- ROW_NUMBER keeps only the nearest site for each student in the final join.
    nearest_campus_site AS (
        SELECT s.student_id,
               c.campus_service_site_name,
               c.city,
               ROUND(
                   SDO_GEOM.SDO_DISTANCE(
                       s.location,
                       c.location,
                       0.005,
                       'unit=KM'
                   ),
                   2
               ) AS distance_to_campus_site_km,
               ROW_NUMBER() OVER (
                   PARTITION BY s.student_id
                   ORDER BY SDO_GEOM.SDO_DISTANCE(
                       s.location,
                       c.location,
                       0.005,
                       'unit=KM'
                   )
               ) AS site_rank
        FROM highered_students_v s
        CROSS JOIN campus_service_sites_v c
        WHERE c.is_active = 1
    )
    -- CONVERGED RESULT: join the outputs of the four data-model operations
    -- into one student-success dashboard review result.
    -- Demand score leads the review order; semantic similarity breaks ties.
    SELECT rc.student,
           rc.service_name,
           rc.request_status,
           rc.demand_score,
           sm.semantic_similarity,
           NVL(jra.json_service_count, 0) AS json_service_count,
           ncs.campus_service_site_name AS nearest_campus_service_site,
           ncs.city AS campus_city,
           ncs.distance_to_campus_site_km
    FROM request_context rc
    LEFT JOIN semantic_match sm
      ON sm.service_id = rc.service_id
    LEFT JOIN json_request_activity jra
      ON jra.request_id = rc.request_id
    JOIN nearest_campus_site ncs
      ON ncs.student_id = rc.student_id
     AND ncs.site_rank = 1
    ORDER BY rc.demand_score DESC,
             sm.semantic_similarity DESC NULLS LAST,
             rc.student
    FETCH FIRST 10 ROWS ONLY;
    </copy>
    ```

3. Review the result as the student-service data behind Jessica's dashboard. Each row combines demand score, semantic service match, the JSON request shape, and the nearest campus service site. This gives the dashboard a ranked review list and the details a student-success team needs when deciding what to review.

    Expected output: Student-Service Dashboard Review

    ![SQL Worksheet showing the ranked student-service result behind Jessica's dashboard](images/product-level-dashboard.png " ")

    Your numbers may be different if the demo data has changed. Each row should include all four types of data.

Use the first row to explain the business takeaway: the demand score shows why the request needs attention, the semantic match explains why the service fits the support question, the JSON count confirms the application request shape, and the campus site shows where coordination could begin. Jessica now has the query behind the dashboard's ranked student-service review list, combining relational request data, vector search, JSON request data, and spatial distance in one result that a campus team can inspect.

With separate systems, Jessica would need complex and expensive integration across a student-information system, search service, document store, and mapping system before the dashboard could show this view. Oracle AI Database keeps these data types together, so she can build the dashboard with SQL. KPI cards and other dashboard components can use additional SQL over the same database.

## Task 2: Change the student-support question

Jessica meets with a student-success analyst to review the results at the data level before she builds the dashboard. They now want to find services related to **financial aid form deadline and student account guidance**. Change the embedded support phrase to:


```text
financial aid form deadline and student account guidance
```

![SQL Worksheet showing the revised HE support phrase and student-service review results](images/2026-08-18-004703.png)


Run the query again and compare the top rows.

1. Which services moved into or out of the top results?
2. Which service now has the strongest semantic match to the new question?
3. Does the request demand score support the same review priority?

The result is ordered by demand score first, with semantic similarity used as a tie-breaker. Changing the question changes the semantic evidence associated with each requested service. The same governed query can answer a different student-support question without rebuilding a search index or moving service data.


## Next Steps

Next, use JSON Relational Duality to expose the same student-service request data as JSON for an application while keeping SQL access for the database team.

## Acknowledgements

* **Author** - Pat Shepherd
* **Last Updated By/Date** - Pat Shepherd, September 2026
